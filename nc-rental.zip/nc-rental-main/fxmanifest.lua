fx_version 'cerulean'
games { 'gta5' }

author 'NaorNC - github.com/NaorNC'
description 'Discrod - NaorNC#8998'
version '1.2'

client_scripts {
  'config.lua',
  'client/cl_*.lua',
}

server_scripts {
  'config.lua',
  'server/sv_*.lua',
}
